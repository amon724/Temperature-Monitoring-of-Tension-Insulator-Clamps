import socket
import threading
import tkinter as tk
from tkinter import messagebox, filedialog
import cv2
import numpy as np
from matplotlib import cm, pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import csv
import winsound  # 用于声音报警
from datetime import datetime  # 用于记录时间日期

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 全局变量
data_buffer = []
frame_buffer = []
is_running = False
conn = None
thread = None
save_counter = 0
video_writer = None
temperature_history = []  # 用于存储温度历史数据（最高和最低温度）
low_threshold = 10.0  # 默认低温阈值
high_threshold = 50.0  # 默认高温阈值
log_history = []  # 用于存储日志记录

# 设置服务器IP和端口
SERVER_IP = '0.0.0.0'
SERVER_PORT = 8080

# 创建socket对象
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((SERVER_IP, SERVER_PORT))
s.listen(1)
print(f"Listening on {SERVER_IP}:{SERVER_PORT}")

# 初始化图像显示
fig = Figure(figsize=(8, 6), dpi=100)
ax = fig.add_subplot(111)
im = ax.imshow(np.zeros((24, 32, 3), dtype=np.uint8), cmap=cm.plasma, interpolation='nearest')
ax.axis('off')

# 初始化文本对象，用于显示最高和最低温度
temp_text = ax.text(0.5, 1.05, '', ha='center', va='center', transform=ax.transAxes, fontsize=12,
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.5))

# 初始化直方图
hist_fig = Figure(figsize=(6, 4), dpi=100)
hist_ax = hist_fig.add_subplot(111)
hist_ax.set_title('温度分布')
hist_ax.set_xlabel('温度(°C)')
hist_ax.set_ylabel('频率')

# 初始化实时趋势图
trend_fig = Figure(figsize=(6, 4), dpi=100)
trend_ax = trend_fig.add_subplot(111)
trend_ax.set_title('温度趋向')
trend_ax.set_xlabel('时间')
trend_ax.set_ylabel('温度(°C)')


# 获取当前时间
def get_current_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# 更新图像的函数
def update_image():
    global frame_buffer
    if len(frame_buffer) >= 768:
        frame = frame_buffer[:768]
        frame_buffer = frame_buffer[768:]  # 移除已处理的数据
        try:
            image_data = process_frame(frame)
            if image_data is not None:
                im.set_data(image_data)
                min_temp = np.min(frame)
                max_temp = np.max(frame)
                temp_text.set_text(f'Min: {min_temp:.2f}°C  Max: {max_temp:.2f}°C')
                canvas.draw()  # 更新图像显示
                update_histogram(frame)  # 更新直方图
                update_trend(frame, min_temp, max_temp)  # 更新趋势图
                # 视频采集
                if video_writer is not None:
                    cv_image = cv2.cvtColor(image_data, cv2.COLOR_RGB2BGR)
                    video_writer.write(cv_image)
                # 检查温度报警
                check_temperature_alert(frame)
                # 记录日志
                current_time = get_current_time()
                refresh_log_display()
        except Exception as e:
            current_time = get_current_time()
            print(f"Error updating image: {e}")
            log_history.append(f"[{current_time}] 图像更新失败: {e}")
            refresh_log_display()


def process_frame(frame):
    try:
        if len(frame) != 768:
            current_time = get_current_time()
            print("Invalid frame length:", len(frame))
            return None

        min_temp = min(frame)
        max_temp = max(frame)
        # 原始图像尺寸 (24x32)
        original_height, original_width = 24, 32
        # 目标图像尺寸（例如放大2倍，变为48x64）
        target_height, target_width = original_height * 8, original_width * 8
        image_data = np.zeros((target_height, target_width, 3), dtype=np.uint8)

        # 双线性插值
        for i in range(target_height):
            for j in range(target_width):
                # 计算目标像素在原始图像中的浮点坐标
                x = j * (original_width - 1) / (target_width - 1)
                y = i * (original_height - 1) / (target_height - 1)

                # 找到邻近的四个像素
                x_floor = int(np.floor(x))
                y_floor = int(np.floor(y))
                x_ceil = min(x_floor + 1, original_width - 1)
                y_ceil = min(y_floor + 1, original_height - 1)

                # 计算权重
                dx1 = x - x_floor
                dx2 = 1 - dx1
                dy1 = y - y_floor
                dy2 = 1 - dy1

                # 获取四个邻近像素的温度值
                temp_floor_floor = frame[y_floor * original_width + x_floor]
                temp_floor_ceil = frame[y_floor * original_width + x_ceil]
                temp_ceil_floor = frame[y_ceil * original_width + x_floor]
                temp_ceil_ceil = frame[y_ceil * original_width + x_ceil]

                # 双线性插值计算
                temp = (temp_floor_floor * dx2 * dy2 +
                        temp_floor_ceil * dx1 * dy2 +
                        temp_ceil_floor * dx2 * dy1 +
                        temp_ceil_ceil * dx1 * dy1)

                # 映射到颜色
                color = map_temp_to_color(temp, min_temp, max_temp)
                image_data[i, j] = (int(color[0] * 255), int(color[1] * 255), int(color[2] * 255))

        return image_data
    except Exception as e:
        current_time = get_current_time()
        print(f"Error processing frame: {e}")
        return None


# 定义RGB565颜色映射函数
def map_temp_to_color(temp, min_temp, max_temp):
    norm_temp = (temp - min_temp) / (max_temp - min_temp)
    return cm.plasma(norm_temp)[:3]  # 确保只获取RGB三个通道


# 接收数据的线程
def receive_data():
    global frame_buffer
    buffer = ""
    while True:
        try:
            if conn is not None:
                part = conn.recv(1024)
                if not part:
                    current_time = get_current_time()
                    log_history.append(f"[{current_time}] 无数据接收，连接可能已关闭.")
                    refresh_log_display()
                    break
                buffer += part.decode('utf-8', errors='ignore')
                if '\n' in buffer:
                    lines = buffer.split('\n')
                    for line in lines[:-1]:
                        try:
                            if not line.strip():
                                continue
                            row = [float(t) for t in line.split(',')]
                            if len(row) == 32:
                                frame_buffer += row
                                current_time = get_current_time()
                        except ValueError:
                            current_time = get_current_time()
                    buffer = lines[-1]
                    update_image()  # 触发图像更新
            else:
                current_time = get_current_time()
                log_history.append(f"[{current_time}] 连接未建立")
                refresh_log_display()
                break
        except Exception as e:
            current_time = get_current_time()
            print(f"Error receiving data: {e}")
            log_history.append(f"[{current_time}] 接收数据失败: {e}")
            refresh_log_display()
            break


# 启动/停止监控
def toggle_monitor():
    global is_running, conn, thread
    if not is_running:
        try:
            conn, addr = s.accept()
            current_time = get_current_time()
            print(f"Connected by {addr}")
            log_history.append(f"[{current_time}] 已连接到客户端: {addr}")
            thread = threading.Thread(target=receive_data)
            thread.daemon = True
            thread.start()
            is_running = True
            start_stop_button.config(text="停止监控")
            current_time = get_current_time()
            log_history.append(f"[{current_time}] 监控已启动")
        except Exception as e:
            current_time = get_current_time()
            messagebox.showerror("错误", f"启动监控失败: {e}")
            log_history.append(f"[{current_time}] 启动监控失败: {e}")
    else:
        is_running = False
        start_stop_button.config(text="启动监控")
        try:
            if conn is not None:
                conn.close()
                current_time = get_current_time()
                log_history.append(f"[{current_time}] 监控已关闭")
        except Exception as e:
            current_time = get_current_time()
            print(f"Error closing connection: {e}")
            log_history.append(f"[{current_time}] 关闭连接失败: {e}")
    refresh_log_display()


# 保存图像
def save_image():
    global save_counter
    try:
        file_path = f"thermal_image_{save_counter}.png"
        fig.savefig(file_path)
        current_time = get_current_time()
        messagebox.showinfo("成功", f"图像已保存到 {file_path}")
        log_history.append(f"[{current_time}] 图像已保存到 {file_path}")
        save_counter += 1
    except Exception as e:
        current_time = get_current_time()
        messagebox.showerror("错误", f"保存图像失败: {e}")
        log_history.append(f"[{current_time}] 保存图像失败: {e}")
    refresh_log_display()


# 更新直方图
def update_histogram(frame):
    hist_ax.clear()
    hist_ax.hist(frame, bins=20, color='b', alpha=0.7)
    hist_ax.set_title('温度分布')
    hist_ax.set_xlabel('温度 (°C)')
    hist_ax.set_ylabel('频率')
    hist_canvas.draw()
    current_time = get_current_time()
    refresh_log_display()


# 更新趋势图
def update_trend(frame, min_temp, max_temp):
    global temperature_history
    temperature_history.append((min_temp, max_temp))  # 存储当前帧的最低和最高温度
    trend_ax.clear()

    # 分别存储最小温度和最大温度的历史记录
    min_temps = [t[0] for t in temperature_history]
    max_temps = [t[1] for t in temperature_history]

    # 绘制两条折线：一条表示最低温度，另一条表示最高温度
    trend_ax.plot(min_temps, color='b', label='最低温度', marker='.')
    trend_ax.plot(max_temps, color='r', label='最高温度', marker='.')

    trend_ax.set_title('温度趋向')
    trend_ax.set_xlabel('时间')
    trend_ax.set_ylabel('温度(°C)')
    trend_ax.legend()  # 显示图例
    trend_canvas.draw()

    current_time = get_current_time()
    refresh_log_display()


# 温度报警
def check_temperature_alert(frame):
    global low_threshold, high_threshold
    if np.min(frame) < low_threshold or np.max(frame) > high_threshold:
        messagebox.showwarning("温度报警", "温度超出设定范围！")
        winsound.Beep(1000, 1000)  # 播放报警声音
        current_time = get_current_time()
        log_history.append(f"[{current_time}] 温度报警：温度超出阈值范围")
    refresh_log_display()


# 导出数据
def export_data():
    global temperature_history
    file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
    if file_path:
        with open(file_path, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["时间", "最低温度", "最高温度"])
            for i, (min_temp, max_temp) in enumerate(temperature_history):
                writer.writerow([i, min_temp, max_temp])
        current_time = get_current_time()
        messagebox.showinfo("成功", f"数据已导出到 {file_path}")
        log_history.append(f"[{current_time}] 数据已导出到 {file_path}")
    else:
        current_time = get_current_time()
        log_history.append(f"[{current_time}] 数据导出取消")
    refresh_log_display()


# 更新日志显示
def refresh_log_display():
    log_text.config(state=tk.NORMAL)
    log_text.delete(1.0, tk.END)
    log_text.insert(tk.END, "\n".join(log_history))
    log_text.config(state=tk.DISABLED)
    log_text.see(tk.END)


# 创建主窗口
root = tk.Tk()
root.title("温度监控系统")
root.geometry("1200x800")
root.configure(bg="#f0f0f0")

# 图像显示区域
canvas = FigureCanvasTkAgg(fig, master=root)
canvas_widget = canvas.get_tk_widget()
canvas_widget.place(x=10, y=10, width=760, height=510)

# 直方图显示区域
hist_canvas = FigureCanvasTkAgg(hist_fig, master=root)
hist_widget = hist_canvas.get_tk_widget()
hist_widget.place(x=790, y=10, width=410, height=250)

# 趋势图显示区域
trend_canvas = FigureCanvasTkAgg(trend_fig, master=root)
trend_widget = trend_canvas.get_tk_widget()
trend_widget.place(x=790, y=270, width=410, height=250)

# 控制按钮
button_frame = tk.Frame(root, bg="#f0f0f0")
button_frame.place(x=790, y=530, width=370, height=260)

start_stop_button = tk.Button(button_frame, text="启动监控", command=toggle_monitor, width=15, height=2,
                              bg="#4CAF50", fg="white", font=("Arial", 12))
start_stop_button.pack(pady=10)

save_button = tk.Button(button_frame, text="保存图像", command=save_image, width=15, height=2,
                        bg="#008CBA", fg="white", font=("Arial", 12))
save_button.pack(pady=10)

export_button = tk.Button(button_frame, text="导出数据", command=export_data, width=15, height=2,
                          bg="#4CAF50", fg="white", font=("Arial", 12))
export_button.pack(pady=10)

# 温度阈值设置
threshold_frame = tk.LabelFrame(root, text="温度阈值设置", bg="#f0f0f0", font=("Arial", 12))
threshold_frame.place(x=550, y=550, width=240, height=160)

low_label = tk.Label(threshold_frame, text="低温阈值:", bg="#f0f0f0", font=("Arial", 12))
low_label.grid(row=0, column=0, padx=10, pady=5)
low_entry = tk.Entry(threshold_frame, width=10, font=("Arial", 12))
low_entry.grid(row=0, column=1, padx=10, pady=5)
low_entry.insert(0, str(low_threshold))

high_label = tk.Label(threshold_frame, text="高温阈值:", bg="#f0f0f0", font=("Arial", 12))
high_label.grid(row=1, column=0, padx=10, pady=5)
high_entry = tk.Entry(threshold_frame, width=10, font=("Arial", 12))
high_entry.grid(row=1, column=1, padx=10, pady=5)
high_entry.insert(0, str(high_threshold))


def update_threshold():
    global low_threshold, high_threshold, log_history
    try:
        new_low = low_entry.get().strip()
        new_high = high_entry.get().strip()
        low_threshold = float(new_low)
        high_threshold = float(new_high)
        current_time = get_current_time()
        messagebox.showinfo("成功", "温度阈值已更新！")
        log_history.append(f"[{current_time}] 温度阈值已更新为：低温 {low_threshold:.1f}°C，高温 {high_threshold:.1f}°C")
    except ValueError:
        current_time = get_current_time()
        messagebox.showerror("错误", "请输入有效的温度值！")
        log_history.append(f"[{current_time}] 温度阈值更新失败：无效的输入值")
    refresh_log_display()


update_button = tk.Button(threshold_frame, text="更新阈值", command=update_threshold, width=12, height=1,
                          bg="#4CAF50", fg="white", font=("Arial", 12))
update_button.grid(row=2, column=0, columnspan=2, pady=10)

# 状态栏
status_bar = tk.Label(root, text="状态: 等待连接...", bd=1, relief=tk.SUNKEN, anchor=tk.W, bg="#f0f0f0")
status_bar.place(x=0, y=780, width=1200, height=20)

# 日志显示区域
log_frame = tk.LabelFrame(root, text="日志显示", bg="#f0f0f0", font=("Arial", 12))
log_frame.place(x=10, y=530, width=500, height=250)

log_text = tk.Text(log_frame, bg="white", fg="black", font=("Arial", 10), state=tk.DISABLED)
log_text.place(x=5, y=5, width=490, height=240)

# 初始化日志显示
current_time = get_current_time()
log_history.append(f"[{current_time}] 程序开始运行")
refresh_log_display()

# 主循环
root.mainloop()