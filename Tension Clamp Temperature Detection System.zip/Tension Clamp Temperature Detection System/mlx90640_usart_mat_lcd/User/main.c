#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "mlx90640.h"
#include "iic.h"
#include "Lcd_Driver.h"
#include "GUI.h"
#include "stdio.h"
#include "8266.h"

int main()
{
		/*******ͨ�ñ���*********/
	u8 sensorAddr=0x66,error=0;//0xFE Ĭ��0x66��0xe6
	static u16 eeMLX90640[832];//3?��??��
	static float mlx90640To[832]={0};
	paramsMLX90640 mlx90640;
	float Ta,tr;
  u16 frame[834];
	float emissivity=0.95;//������0.95
	char tc[6]={0x30};
	u16 i=0,j=0,k=0,n=0,temp=0; 
	static uint32_t lastSendTime = 0;
	/************LCD��ʾ����******************/
	u16 clr_r,clr_g,clr_b;
	u16 x_col,y_col,s_col,T_range;
	u16 u_x,u_y;
	static u16 clr_map[300];//__attribute__((at(0x68000000)));
	static float min,max;
	static u16 scale_min,scale_max;
	char tstr[16];
	u16 min_loc,max_loc;
	/*********************ϵͳ��ʼ��******/
	SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�ж����ȼ����� ��2��
	LED_Init();
	USART1_Init(115200);
	IIC_Init();
	Lcd_Init();
	LCD_LED_SET;//ͨ��IO���Ʊ�����	
  //Lcd_Reset();
		//WIFIģ��
	Esp8266Init();
	ConnectToHotspot();
	delay_ms(3000);
	ConnectServer();
	Lcd_Clear(WHITE);
	// ��ʾ����ͼ
  clr_r=0xf800;//red
	clr_g=0x07e0;//green
	clr_b=0x00ef;//blue
	clr_r>>=11;
	clr_g>>=6;
  k=20;
	for(i=0;i<k/2;i++)
	   clr_map[i]=(((i+k/2)*clr_r/k)<<11);//0x0000��ɫ��0xffff��ɫ
	for(i=k/2;i<k;i++)
	   clr_map[i]=(clr_r<<11)|(((i-k/2)*clr_g/k)<<6);//0x0000��ɫ��0xffff��ɫ	
	for(i=k;i<(k+k);i++)
	   clr_map[i]=(clr_r<<11)|(((i)*clr_g/(k+k))<<6);//0x0000��ɫ��0xffff��ɫ		 
	for(i=k+k;i<(k+k+k);i++)
	   clr_map[i]=((clr_r-(i-k-k)*clr_r/k)<<11)|((clr_g)<<6);//0x0000��ɫ��0xffff��ɫ		 
  x_col=0;
  y_col=20;
  s_col=1;
	n=0;
	T_range=3*k;//50->*3 100->*3/2 300->/2  150->150ȷ����Χһ��
	for(j=0;j<(k+k+k);j++)	
	{	
		  
		Gui_DrawRegionPoint(x_col,y_col+j*s_col,x_col+s_col+10,y_col+j*s_col+s_col,clr_map[j]);
		if(j%15<1)
		{
		    Gui_DrawRegionPoint(x_col+s_col+11,y_col+j*s_col,x_col+s_col+10+2,y_col+j*s_col+s_col,0x0000);
			  sprintf(tstr,"%d",T_range-n*T_range/10);
			  Gui_DrawFont_GBK16(x_col+s_col+12,y_col+j*s_col-5,RED,GRAY0,tstr);
			  n=n+1;
		}		
	}
	Gui_DrawFont_GBK16(25,1,RED,GRAY0,"�ȳ���ϵͳ");
	//Gui_DrawFont_Num32(0,0,RED,GRAY0,20);		
  //Gui_DrawFont_GBK16(16,20,RED,GRAY0,"Һ�����Գ���")	;
	if(error==0)
		{
			delay_ms(10);
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET){};
      USART_SendData(USART1,0x59);//Y
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);		
		}
		else
		{
			delay_ms(10);
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET){};
      USART_SendData(USART1,0x4E);//N
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);			
		}
	/*********************MLX90640��ʼ��******/
		
	error=i2c_write_cmd16(sensorAddr,ConReg1,Rate4HZ_CH);	
	MLX90640_DumpEE(sensorAddr, eeMLX90640);	
  MLX90640_ExtractParameters(eeMLX90640, &mlx90640);
		
	while(1)
	{
			if(max>100)	 	 
				Lcd_Clear(WHITE);	 

   error=i2c_write_cmd16(sensorAddr,ConReg1,Rate4HZ_CH);
		if(error==0)
		{
			delay_ms(10);
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET){};
      USART_SendData(USART1,0x59);//Y
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);		
		}
		else
		{
			delay_ms(10);
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET){};
      USART_SendData(USART1,0x4E);//N
		  while(USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);			
		}
		
	  MLX90640_GetFrameData(sensorAddr,frame);
    Ta = MLX90640_GetTa(frame, &mlx90640);
    tr = Ta - TA_SHIFT;
    MLX90640_CalculateTo(frame, &mlx90640, emissivity, tr, mlx90640To);
		
    for (i = 0; i < 24; i++){
			SendThermalDataLine(&mlx90640To[i * 32], 32);
			delay_us(25);
    }
		/****************************����������ʵͼ��************************************/
		find_max_min(mlx90640To,&max,&min,&max_loc,&min_loc,768);
		scale_min=floor(min);
		scale_max=ceil(max);
		sprintf(tstr,"max=%.2f",max);
		Gui_DrawFont_GBK16(25,95,RED,GRAY0,tstr);
		sprintf(tstr,"min=%.2f",min);
		Gui_DrawFont_GBK16(25,110,RED,GRAY0,tstr);
		
		x_col=0;
    y_col=20;
    s_col=1;
		n=0;
		k=20;
		T_range=(max-min)/3;
		for(j=0;j<(k+k+k);j++)	
		{	
			if(j%15<1)
			{
				  sprintf(tstr,"%d",scale_max-n*T_range);
				  Gui_DrawFont_GBK16(x_col+s_col+12,y_col+j*s_col-5,RED,GRAY0,tstr);
					n=n+1;
			}		
		}
		sprintf(tstr,"%d",scale_min);
		Gui_DrawFont_GBK16(x_col+s_col+12,y_col+j*s_col-5,RED,GRAY0,tstr);
		
		
		//������ɫ������
		x_col=30;
    y_col=20;
    s_col=3;
    k=0;
		// �����ȳ���ͼ��
		for(i=0;i<24;i++)
		{
		   for(j=0;j<32;j++)
			{
			  u_y=mlx90640To[k];
				u_y=(u_y-scale_min)*(60/(scale_max-scale_min));//
				if(u_y>=60)
					u_y=59;

				//Gui_DrawPoint(50+j,50+i,clr_map[59-u_y]);//���һ����
				Gui_DrawRegionPoint(x_col+j*s_col,y_col+i*s_col,x_col+j*s_col+s_col,y_col+i*s_col+s_col,clr_map[59-u_y]);//���һ����
				/*
				if(u_y>=(u16)max)//k==max_loc
				 Gui_DrawRegionPoint(x_col+j*s_col,y_col+i*s_col,x_col+j*s_col+s_col,y_col+i*s_col+s_col,0xf800);//��ɫ
			  if(u_y<=(u16)min)//k==min_loc
					Gui_DrawRegionPoint(x_col+j*s_col,y_col+i*s_col,x_col+j*s_col+s_col,y_col+i*s_col+s_col,0x00ef);//��ɫ
			*/	
				k=k+1;
			}
		}
	}
}
