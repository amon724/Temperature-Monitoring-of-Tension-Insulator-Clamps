#ifndef __8266_H
#define __8266_H

#include "system.h" 
#include "stm32f10x.h"
#include "string.h"
#include "SysTick.h"
#include "stdio.h"
#include "stdlib.h"
#include "Lcd_Driver.h"
#include "LCD_Config.h"
#include "key.h"

#define ACCOUNT  "hyx"    
#define PASSWORD "88888888"  
#define SERVERIP "192.168.203.66"
#define SERVERPORT 8080

#define MAX_LINE_WIDTH 32
#define BUFFER_SIZE (MAX_LINE_WIDTH * 10)

#define RXMAX  1024

typedef struct{
	uint8_t rxbuff[RXMAX];//�������ݻ���
	uint16_t rxcount;   //���յ�����
	uint8_t rxover;   //���յ�����
	uint8_t txbuff[RXMAX];//�������ݻ���
}__MESSAGE;

typedef struct{
	uint8_t date[24];//�������ݻ���
	uint16_t text_day;   //���յ�����
	uint8_t humi; //ʪ��
	
}__WEATHERMESSAGE;

#define WIFIAPDATAADDR     0x00  //����ֻ�APP���͹���������



enum{
WIFI_ACK_OK,WIFI_ACK_ERROR
};



typedef struct{
	char account[12];
	char password[12];
	char city[30];
	uint8_t alarmhour;
	uint8_t alarmmin;
}APDATA;

extern APDATA appdata;
extern __MESSAGE wifimessage;


void ConnectToHotspot(void);
void Clear_BuffData(void);

uint8_t Wifi_OpenTransmission(void);
void Wifi_CloseTransmission(void);
uint8_t Wifi_ConnectServer(char *mode,char *ip,uint16_t port);

void Esp8266Init(void);//Esp8266��ʼ��
void Esp8266PortInit(void);
void WifiSendStr(char *p);
void Usart3_SendByte(uint8_t data);
void WifiSendbuff(uint8_t *p,uint8_t lenth);
uint8_t WifiSendRevAck(char *cmd,char *ack,uint32_t timeout,uint8_t check_cnt);
char *FindStr(char *dest,char *src,uint32_t outtime);
uint8_t ConnectServer(void);
void SendThermalDataLine(float *data, int width);

#endif

