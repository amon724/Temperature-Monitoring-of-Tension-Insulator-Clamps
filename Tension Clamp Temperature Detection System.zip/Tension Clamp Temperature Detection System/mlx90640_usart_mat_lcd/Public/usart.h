#ifndef __usart_H
#define __usart_H

#include "system.h" 


void USART1_Init(u32 bound);
void UART1_SendString(char* str);

#endif


